using System;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter first number:");
            double num1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter second number:");
            double num2 = double.Parse(Console.ReadLine());

            Console.WriteLine("Summation: " + (num1 + num2));
            Console.WriteLine("Subtraction: " + (num1 - num2));
            Console.WriteLine("Multiplication: " + (num1 * num2));
            Console.WriteLine("Division: " + (num1 / num2));

            Console.ReadLine();
        }
    }
}
